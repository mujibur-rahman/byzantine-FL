#!/bin/bash
# run_all.sh — Execute all experiments (Weeks 4 + 5) in order
# Estimated runtime: 40-70 minutes on a standard CPU

set -e
cd "$(dirname "$0")"
mkdir -p results

echo "============================================================"
echo " Byzantine-Resilient FL — Full Experiment Suite"
echo " Start: $(date)"
echo "============================================================"

pip install numpy pandas scikit-learn scipy --quiet

echo ""
echo "[1/5] Baseline comparison (+ FLAME)..."
python3 experiment1_baselines.py 2>&1 | tee results/exp1.log

echo ""
echo "[2/5] Sensitivity analysis (tau, alpha, delta)..."
python3 experiment2_sensitivity.py 2>&1 | tee results/exp2.log

echo ""
echo "[3/5] Per-layer confusion breakdown..."
python3 experiment3_layer_analysis.py 2>&1 | tee results/exp3.log

echo ""
echo "[4/5] Computational overhead..."
python3 experiment4_overhead.py 2>&1 | tee results/exp4.log

echo ""
echo "[5/5] Adaptive adversary (sleeper / mimicry / slow-drift)..."
python3 experiment5_adaptive.py 2>&1 | tee results/exp5.log

echo ""
echo "============================================================"
echo " All experiments complete: $(date)"
echo ""
echo " Results files:"
echo "   results/table_baselines.csv          → Table VI  (updated)"
echo "   results/sensitivity_*.csv            → Table IX  (new)"
echo "   results/layer_confusion.csv          → Table X   (new)"
echo "   results/overhead.csv                 → Table XI  (new)"
echo "   results/adaptive_detection_latency.csv → Table XII (new)"
echo ""
echo " LaTeX-ready output:"
echo "   results/layer_confusion_latex.txt"
echo "   results/overhead_latex.txt"
echo "   results/adaptive_latex.txt"
echo ""
echo " After running, replace all '--' placeholders in"
echo " byzantine-FL-week5.tex with values from these files."
echo "============================================================"
